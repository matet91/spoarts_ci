<div id="message">
<div style="padding: 5px;">
    <div id="inner-message" class="alert alert-error">
    </div>
</div>
</div>
<div id="content">
    <div class="container">
	   
	     <div class = "row">
	     	<div class = "col-xs-6 col-md-2">&nbsp;
	      	</div>
	      	<div class = "col-xs-6 col-md-8">
	      		<div class="jumbotron">
	      		<img alt="" src="assets/images/logo.png" style = "margin-left: -8%;position: absolute;margin-top: -11%;z-index: 2147483647;">
		 			<h3 class="classic-title"><span>Please select your Security Question</span></h3>
		 			<div class = "row">
		 				<form id="firstlogin_sp_sq">
		 					<div class = "row">
		 						<div class = "form-group">
		 							<select id = "security_question_id" name="security_question_id" class="form-control">
		 							</select>
		 						</div>
		 					</div>
		 					<div class = "row">
		 						<div class = "form-group">
		 							<input type="password" id = "sec_pwd" name="sec_pwd" class="form-control">
		 						</div>
		 					</div>
		 				</form>
		 				<button type="button" id="saveSQSettings" class="btn btn-lg btn-primary">Save Changes</button>
		 			</div>
				</div>
		  	</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="assets/js/firstlogin.js"></script>